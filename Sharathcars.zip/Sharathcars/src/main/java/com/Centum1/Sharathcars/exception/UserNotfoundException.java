package com.Centum1.Sharathcars.exception;

public class UserNotfoundException extends Exception{
    public UserNotfoundException(String message){

        super(message);
    }
}
