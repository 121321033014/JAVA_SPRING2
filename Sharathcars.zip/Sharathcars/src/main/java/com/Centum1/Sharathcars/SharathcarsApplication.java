package com.Centum1.Sharathcars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SharathcarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SharathcarsApplication.class, args);
	}

}
