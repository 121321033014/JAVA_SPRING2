package com.Centum1.Sharathcars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SharathcarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
